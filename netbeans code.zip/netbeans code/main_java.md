package aistudyassistant;

/**
 * Main application driver for testing the AI Study Assistant Design Patterns.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println(">>> TESTING SINGLETON PATTERN <<<");
        DatabaseConnection db = DatabaseConnection.getInstance();
        db.query("SELECT * FROM user_embeddings");

        System.out.println("\n>>> TESTING FACTORY PATTERN <<<");
        Question q1 = QuestionFactory.createQuestion("MCQ");
        q1.display();

        System.out.println("\n>>> TESTING FACADE PATTERN <<<");
        StudyAssistantFacade aiSystem = new StudyAssistantFacade();
        aiSystem.uploadAndQuery("Software_Design_Slides.pdf", "Explain the Factory Pattern.");

        System.out.println("\n>>> TESTING MVC PATTERN <<<");
        StudentModel model = new StudentModel();
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);
        
        controller.setStudentData("Syed Haider Ali Shah", 92);
        controller.updateDashboard();
    }
}