package aistudyassistant;

/**
 * Facade Pattern: Provides a unified, simplified interface for the complex 
 * Document Processing and Retrieval-Augmented Generation (RAG) subsystems.
 */
class DocumentProcessor {
    public void processPDF(String filename) {
        System.out.println("[Processing] Extracting and chunking text from: " + filename);
    }
}

class RAGEngine {
    public void generateAnswer(String query) {
        System.out.println("[RAG Engine] Retrieving vectors and generating citation-backed answer for: '" + query + "'");
    }
}

public class StudyAssistantFacade {
    private DocumentProcessor docProcessor;
    private RAGEngine ragEngine;

    public StudyAssistantFacade() {
        this.docProcessor = new DocumentProcessor();
        this.ragEngine = new RAGEngine();
    }

    public void uploadAndQuery(String filename, String query) {
        docProcessor.processPDF(filename);
        ragEngine.generateAnswer(query);
    }
}