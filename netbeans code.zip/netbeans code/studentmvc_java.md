package aistudyassistant;

/**
 * MVC Pattern: Separates the Student data (Model), the Dashboard UI (View), 
 * and the logic updating the metrics (Controller).
 */
class StudentModel {
    private String name;
    private int masteryScore;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getMasteryScore() { return masteryScore; }
    public void setMasteryScore(int score) { this.masteryScore = score; }
}

class StudentView {
    public void printDashboard(String studentName, int score) {
        System.out.println("\n==================================");
        System.out.println("   STUDENT PROGRESS DASHBOARD");
        System.out.println("==================================");
        System.out.println("Student Name : " + studentName);
        System.out.println("Mastery Score: " + score + "%");
        System.out.println("==================================\n");
    }
}

class StudentController {
    private StudentModel model;
    private StudentView view;

    public StudentController(StudentModel model, StudentView view) {
        this.model = model;
        this.view = view;
    }

    public void setStudentData(String name, int score) { 
        model.setName(name); 
        model.setMasteryScore(score);
    }
    
    public void updateDashboard() { 
        view.printDashboard(model.getName(), model.getMasteryScore()); 
    }
}