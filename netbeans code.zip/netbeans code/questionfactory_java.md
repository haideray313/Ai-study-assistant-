package aistudyassistant;

/**
 * Factory Pattern: Dynamically generates different types of assessment questions
 * (MCQs, Short Answer) based on the AI's content evaluation.
 */
interface Question {
    void display();
}

class MCQQuestion implements Question {
    @Override
    public void display() {
        System.out.println("[Quiz] Generating Multiple Choice Question from course material...");
    }
}

class ShortAnswerQuestion implements Question {
    @Override
    public void display() {
        System.out.println("[Quiz] Generating Short Answer Question requiring source citation...");
    }
}

public class QuestionFactory {
    public static Question createQuestion(String type) {
        if (type.equalsIgnoreCase("MCQ")) {
            return new MCQQuestion();
        } else if (type.equalsIgnoreCase("SHORT")) {
            return new ShortAnswerQuestion();
        }
        throw new IllegalArgumentException("Unknown question type.");
    }
}