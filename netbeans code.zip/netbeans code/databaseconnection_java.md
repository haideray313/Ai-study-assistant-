package aistudyassistant;

/**
 * Singleton Pattern: Ensures a single database connection instance is used 
 * across the AI Study Assistant for both PostgreSQL and ChromaDB.
 */
public class DatabaseConnection {
    private static DatabaseConnection instance;
    
    private DatabaseConnection() {
        System.out.println("[Database] Connected to ChromaDB and PostgreSQL.");
    }
    
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    public void query(String sql) {
        System.out.println("[Database] Executing query: " + sql);
    }
}